function searchInme() {
                
                    var input, filter, ul, li, h2, i;
                
                    input = document.getElementById('inventorySearch');
                    filter = input.value.toUpperCase();
                    ul = document.getElementById("ul");
                    li = ul.getElementsByTagName('li');
                
                    // Loops through the name of each robot and displays the one that matches query
                    for (i = 0; i < li.length; i++) {
                        h2 = li[i].getElementsByTagName("h2")[0];
                        if (h2.innerHTML.toUpperCase().indexOf(filter) > -1) {
                            li[i].style.display = "";
                        } else {
                            li[i].style.display = "none";
                        }
                    }
                }
                
function calculate() {
    var input = 0, licenseAmt = 0, taxAmt= 0, tittleAmt = 0, interestRate = 0, interest = 0,
    tax = 0, tittle = 0, license = 0, total = 0, price = 0, intAmt = 0, calculatedPymt = 0,
    months = 0, yourPymt = 0, monthlyPymt = 0;
    
    interestRate = document.getElementById('interest').value;
    input = document.getElementById('price').value;
    months = document.getElementById('months').value;
    
    calculatedPymt = +input + +interest + +tax + +tittle + +license;
    monthlyPymt = +calculatedPymt/+months;
    yourPymt = monthlyPymt.toFixed(2);
    
    
    interest = input * interestRate;
    intAmt = interest.toFixed(2);
    
    tax = input * .008;
    taxAmt = tax.toFixed(2);
    
    tittle = input * .03;
    tittleAmt = tittle.toFixed(2);
    
    license = input * .025;
    licenseAmt = license.toFixed(2);
    
     document.getElementById("payment").innerHTML = yourPymt;
     document.getElementById("tax").innerHTML = taxAmt;
     document.getElementById("tittle").innerHTML = tittleAmt;
     document.getElementById("license").innerHTML = licenseAmt;
     document.getElementById("interestAmt").innerHTML = intAmt;
      
    
}                
                